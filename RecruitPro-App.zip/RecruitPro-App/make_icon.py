"""
Generates a simple RecruitPro icon (blue circle with a white target/briefcase symbol)
and saves it as icon.ico and icon.png
"""
import struct, zlib, os

os.makedirs("assets", exist_ok=True)

def make_png(size):
    """Create a simple PNG: navy background + blue circle + white target dot"""
    import struct, zlib

    w = h = size
    raw = []
    cx, cy, r = w//2, h//2, w*0.42
    ir = r * 0.55
    dot = r * 0.18

    for y in range(h):
        row = b'\x00'
        for x in range(w):
            dx, dy = x - cx, y - cy
            d = (dx*dx + dy*dy) ** 0.5
            # navy bg
            if d > r:
                row += bytes([11, 24, 41, 255])
            # outer ring (cyan/blue)
            elif d > r*0.82:
                row += bytes([37, 99, 235, 255])
            # white gap
            elif d > r*0.62:
                row += bytes([248, 250, 252, 255])
            # inner ring (blue)
            elif d > r*0.44:
                row += bytes([37, 99, 235, 255])
            # white gap
            elif d > r*0.26:
                row += bytes([248, 250, 252, 255])
            # center dot (gold)
            elif d <= r*0.18:
                row += bytes([245, 158, 11, 255])
            else:
                row += bytes([11, 24, 41, 255])
        raw.append(row)

    def make_chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)

    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)
    idat_data = b''.join(raw)
    compressed = zlib.compress(idat_data, 9)

    png  = b'\x89PNG\r\n\x1a\n'
    png += make_chunk(b'IHDR', ihdr)
    png += make_chunk(b'IDAT', compressed)
    png += make_chunk(b'IEND', b'')
    return png

# Write PNGs at multiple sizes
sizes = [16, 32, 48, 64, 128, 256]
pngs  = {}
for sz in sizes:
    pngs[sz] = make_png(sz)

# Save 256px PNG separately
with open("assets/icon.png", "wb") as f:
    f.write(pngs[256])
print("icon.png written")

# Build ICO file (contains 16, 32, 48, 256)
ico_sizes = [16, 32, 48, 256]
count = len(ico_sizes)
header_size = 6 + count * 16
offsets = []
offset = header_size
for sz in ico_sizes:
    offsets.append(offset)
    offset += len(pngs[sz])

ico = struct.pack('<HHH', 0, 1, count)
for i, sz in enumerate(ico_sizes):
    d = sz if sz < 256 else 0
    ico += struct.pack('<BBBBHHII', d, d, 0, 0, 1, 32, len(pngs[sz]), offsets[i])
for sz in ico_sizes:
    ico += pngs[sz]

with open("assets/icon.ico", "wb") as f:
    f.write(ico)
print("icon.ico written:", len(ico), "bytes")
