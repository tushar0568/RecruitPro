# RecruitPro — Windows App Build Guide

## 100% Offline & Independent
After building, RecruitPro works completely without internet.
No cloud. No CDN. All libraries are bundled inside the app.

---

## What you need (free, one-time install)
1. **Node.js** — download from https://nodejs.org
   Choose the "LTS" version → install it → restart your PC

---

## IMPORTANT — Run as Administrator
1. Press **Windows key** → type **cmd**
2. Right-click **Command Prompt** → **"Run as administrator"**
3. Click **Yes**

---

## Build Steps

### Step 1 — Navigate to the folder
```
cd F:\Downloads\RecruitPro-App\RecruitPro-App
```
(adjust path to where you extracted the ZIP)

### Step 2 — Install dependencies + bundle libraries
```
npm install
```
This does two things automatically:
- Downloads Electron and build tools
- Copies React, Babel, SheetJS into src/libs/ (offline bundle)

You will see:
```
✅ React 18 — copied
✅ ReactDOM 18 — copied
✅ Babel Standalone — copied
✅ SheetJS (xlsx) — copied
✅ All libraries bundled! RecruitPro is now 100% offline.
```

### Step 3 — Build the installer
```
npm run build
```
Wait ~5 minutes.

### Step 4 — Get your installer
Open the **dist** folder:
- **RecruitPro Setup 1.0.0.exe** — full installer (recommended)
- **RecruitPro 1.0.0.exe** — portable, no install needed

---

## After installing
- Open from Start Menu or Desktop shortcut
- Works 100% offline — no internet needed ever
- Data saves automatically to your PC

---

## Commands
| Command | What it does |
|---------|-------------|
| `npm install` | Install + bundle all libraries offline |
| `npm start` | Run app for testing (no build) |
| `npm run build` | Build installer + portable .exe |
