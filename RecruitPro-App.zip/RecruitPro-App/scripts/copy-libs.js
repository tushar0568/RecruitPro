/**
 * copy-libs.js — runs automatically after "npm install"
 * Copies all UI library files from node_modules into src/libs/
 * so the app works 100% OFFLINE with no internet needed.
 */
const fs   = require('fs');
const path = require('path');

const ROOT    = path.join(__dirname, '..');
const LIBS    = path.join(ROOT, 'src', 'libs');

// Create src/libs/ folder if it doesn't exist
if (!fs.existsSync(LIBS)) fs.mkdirSync(LIBS, { recursive: true });

const copies = [
  {
    src:  path.join(ROOT, 'node_modules', 'react', 'umd', 'react.production.min.js'),
    dest: path.join(LIBS, 'react.production.min.js'),
    name: 'React 18'
  },
  {
    src:  path.join(ROOT, 'node_modules', 'react-dom', 'umd', 'react-dom.production.min.js'),
    dest: path.join(LIBS, 'react-dom.production.min.js'),
    name: 'ReactDOM 18'
  },
  {
    src:  path.join(ROOT, 'node_modules', '@babel', 'standalone', 'babel.min.js'),
    dest: path.join(LIBS, 'babel.min.js'),
    name: 'Babel Standalone'
  },
  {
    src:  path.join(ROOT, 'node_modules', 'xlsx', 'dist', 'xlsx.full.min.js'),
    dest: path.join(LIBS, 'xlsx.full.min.js'),
    name: 'SheetJS (xlsx)'
  },
];

let allOk = true;
console.log('\n📦 RecruitPro — Bundling libraries for offline use...\n');

for (const { src, dest, name } of copies) {
  try {
    if (!fs.existsSync(src)) {
      console.error(`  ❌ ${name}: source not found at ${src}`);
      allOk = false;
      continue;
    }
    fs.copyFileSync(src, dest);
    const kb = Math.round(fs.statSync(dest).size / 1024);
    console.log(`  ✅ ${name} — ${kb} KB  →  src/libs/${path.basename(dest)}`);
  } catch (e) {
    console.error(`  ❌ ${name}: ${e.message}`);
    allOk = false;
  }
}

if (allOk) {
  console.log('\n✅ All libraries bundled! RecruitPro is now 100% offline.\n');
} else {
  console.warn('\n⚠️  Some libraries could not be copied. Run npm install again.\n');
}
